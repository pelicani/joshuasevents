<div id="views-slideshow-xtra-overlay--<?php print drupal_clean_css_identifier($view->name); ?>--<?php print drupal_clean_css_identifier($view->current_display); ?>" class="<?php print $classes; ?>">
  <?php print $rendered_rows; ?>
</div>
